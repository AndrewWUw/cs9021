/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Description: Tests the functions defined in tailored_tree.h.                *
 *                                                                             *
 * Written by Eric Martin for COMP9021                                         *
 *                                                                             *
 * Other source files, if any, one per line, starting on the next line:        *
 *       tailored_tree.c                                                       *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <stdio.h>
#include <stdlib.h>
#include "tailored_tree.h"

void test_empty_tree(void);
void test_one_node_tree(void);
void test_many_nodes_tree(void);
void test_bst(void);

int main(void) {
    test_empty_tree();
    putchar('\n');
    test_one_node_tree();
    putchar('\n');
    test_many_nodes_tree();
    putchar('\n');
    test_bst();
    return EXIT_SUCCESS;
}

void test_empty_tree(void) {
    Node *const tree = NULL;
    printf("Height of empty tree: %d\n", tree_height(tree));
    printf("Size of empty tree: %d\n", tree_size(tree));
    printf("Empty tree is bst: %s\n", is_bst(tree) ? "yes" : "no");
    printf("0 occurs in empty tree: %s\n", occurs_in_tree(0, tree) ? "yes" : "no");
    printf("0 occurs in empty tree viewed as bst: %s\n", occurs_in_bst(0, tree) ? "yes" : "no");
    printf("Empty tree displayed growing east:\n"), print_binary_tree(tree);
    printf("Preorder traversal of empty tree:\n"), preorder_traverse_tree_and_print(tree);
    printf("Inorder traversal of empty tree:\n"), inorder_traverse_tree_and_print(tree);
    printf("Postorder traversal of empty tree:\n"), postorder_traverse_tree_and_print(tree);
}

void test_one_node_tree(void) {
    Node *tree = create_node(1);
    printf("Test of the tree T consisting of a single node that stores 1.\n");
    printf("Height of T: %d\n", tree_height(tree));
    printf("Size of T: %d\n", tree_size(tree));
    printf("T is bst: %s\n", is_bst(tree) ? "yes" : "no");
    printf("0 occurs in T: %s\n", occurs_in_tree(0, tree) ? "yes" : "no");
    printf("0 occurs in T viewed as bst: %s\n", occurs_in_bst(0, tree) ? "yes" : "no");
    printf("1 occurs in T: %s\n", occurs_in_tree(1, tree) ? "yes" : "no");
    printf("1 occurs in T viewed as bst: %s\n", occurs_in_bst(1, tree) ? "yes" : "no");
    printf("T displayed growing east:\n"), print_binary_tree(tree);
    printf("Preorder traversal of T:\n"), preorder_traverse_tree_and_print(tree);
    printf("Inorder traversal of T:\n"), inorder_traverse_tree_and_print(tree);
    printf("Postorder traversal of T:\n"), postorder_traverse_tree_and_print(tree);
    delete_tree(&tree);
}

void test_many_nodes_tree(void) {
    Node *const tree = create_node(3);
    Node *const node_1 = create_node(2);
    Node *const node_2 = create_node(5);
    Node *const node_3 = create_node(1);
    Node *const node_4 = create_node(4);
    Node *const node_5 = create_node(6);
    Node *const node_6 = create_node(6);
    tree->pt_to_left_node = node_1;
    tree->pt_to_right_node = node_2;
    node_1->pt_to_left_node = node_3;
    node_2->pt_to_left_node = node_4;
    node_2->pt_to_right_node = node_5;
    node_4->pt_to_right_node = node_6;  
    printf("Test of the tree T consisting of 7 nodes that store 1, 2, 3, 4, 5 and 6 twice.\n");
    printf("Height of T: %d\n", tree_height(tree));
    printf("Size of T: %d\n", tree_size(tree));
    printf("T is bst: %s\n", is_bst(tree) ? "yes" : "no");
    printf("7 occurs in T: %s\n", occurs_in_tree(0, tree) ? "yes" : "no");
    printf("4 occurs in T: %s\n", occurs_in_tree(1, tree) ? "yes" : "no");
    printf("T displayed growing east:\n"), print_binary_tree(tree);
    printf("Preorder traversal of T:\n"), preorder_traverse_tree_and_print(tree);
    printf("Inorder traversal of T:\n"), inorder_traverse_tree_and_print(tree);
    printf("Postorder traversal of T:\n"), postorder_traverse_tree_and_print(tree);
}

void test_bst(void) {
    Node *tree = NULL;
    printf("Empty tree:\n"), print_binary_tree(tree);
    insert_in_bst(4, &tree);
    printf("After inserting 4:\n"), print_binary_tree(tree);
    insert_in_bst(2, &tree);
    printf("After inserting 2:\n"), print_binary_tree(tree);
    insert_in_bst(1, &tree);
    printf("After inserting 1:\n"), print_binary_tree(tree);
    insert_in_bst(5, &tree);
    printf("After inserting 5:\n"), print_binary_tree(tree);
     insert_in_bst(3, &tree);
    printf("After inserting 3:\n"), print_binary_tree(tree);
    insert_in_bst(6, &tree);
    printf("After inserting 6:\n"), print_binary_tree(tree);
    insert_in_bst(7, &tree);
    printf("After inserting 7:\n"), print_binary_tree(tree);
    printf("Tree is bst: %s\n", is_bst(tree) ? "yes" : "no");
    printf("3 occurs in tree: %s\n", occurs_in_tree(3, tree) ? "yes" : "no");
    printf("3 occurs in tree viewed as bst: %s\n", occurs_in_bst(3, tree) ? "yes" : "no");
    printf("8 occurs in tree: %s\n", occurs_in_tree(8, tree) ? "yes" : "no");
    printf("8 occurs in tree viewed as bst: %s\n", occurs_in_bst(8, tree) ? "yes" : "no");
    printf("Preorder traversal of tree:\n"), preorder_traverse_tree_and_print(tree);
    printf("Inorder traversal of tree:\n"), inorder_traverse_tree_and_print(tree);
    printf("Postorder traversal of tree:\n"), postorder_traverse_tree_and_print(tree);    
    delete_in_bst(5, &tree, true);
    printf("After deleting 5 lifting left rather than right subtree:\n"), print_binary_tree(tree);
    delete_in_bst(7, &tree, false);
    printf("After deleting 7 lifting right rather than left subtree:\n"), print_binary_tree(tree);
    delete_in_bst(2, &tree, false);
    printf("After deleting 2 lifting right rather than left subtree:\n"), print_binary_tree(tree);
    delete_in_bst(4, &tree, true);
    printf("After deleting 4 lifting left rather than right subtree:\n"), print_binary_tree(tree);
    delete_in_bst(3, &tree, true);
    printf("After deleting 3 lifting left rather than right subtree:\n"), print_binary_tree(tree);
    delete_in_bst(1, &tree, true);
    printf("After deleting 1 lifting left rather than right subtree:\n"), print_binary_tree(tree);
    delete_in_bst(6, &tree, false);
    printf("After deleting 6 lifting right rather than left subtree:\n"), print_binary_tree(tree);
    delete_tree(&tree);
}
