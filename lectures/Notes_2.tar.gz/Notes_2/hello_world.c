/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Description: Prints out hello world!                                        *
 *                                                                             *
 * Purpose: Do what is done at the beginning of any programming course         *
 *                                                                             *
 * Written by Eric Martin for COMP9021                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
     printf("Hello world!\n");
    return EXIT_SUCCESS;
}

